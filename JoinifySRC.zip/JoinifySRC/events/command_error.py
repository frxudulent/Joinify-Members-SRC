# events.py

import discord
from discord.ext import commands
from discord.ext.commands import CommandOnCooldown

@commands.Cog.listener()
async def on_command_error(ctx, error):
    if isinstance(error, CommandOnCooldown):
        # If a command is on cooldown, handle it here
        view = discord.ui.View() # Establish an instance of the discord.ui.View class
        style = discord.ButtonStyle.gray  # The button will be gray in color
        item = discord.ui.Button(style=style, label="Bypass cooldowns", url="https://joinify.mysellix.io")
        view.add_item(item=item)  # Add that item into the view class
        cooldown_embed = discord.Embed(
            title="<a:no_:1198815807648567307> Command Cooldown",
            description=f"This command is on cooldown. Please try again in {error.retry_after:.2f} seconds.",
            color=discord.Color.red()
        )
        await ctx.reply(view=view, embed=cooldown_embed)
